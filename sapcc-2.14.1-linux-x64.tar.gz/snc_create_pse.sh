#!/bin/bash

echo "INFO This script needs to be copied and executed in sapcrypto folder"

serviceSymlinkFile="/usr/local/sbin/rcscc_daemon"

secudirScript=
if [ -r "$serviceSymlinkFile" ]; then
    secudirScript=`awk '
    BEGIN { foundCustomSection = 0; }
    /CUSTOM_SECTION/ {
        if (foundCustomSection == 0) {
            foundCustomSection = 1;
        }
    }
    /export SECUDIR=/ {
        if (foundCustomSection == 1) {
            $0 = substr($0, index($0, "export SECUDIR=") + 15);
            print;
            foundCustomSection = 2;
        }
    }
    ' "$serviceSymlinkFile"`
    if [ ! -d "$secudirScript" ]; then
        if [ -d "$SECUDIR" ]; then
            echo "$secudirScript is not a directory, using $SECUDIR as SECUDIR."
            secudirScript="$SECUDIR"
        else
            echo "$secudirScript is not a directory and env variable \"$SECUDIR\" is not set correctly as SECUDIR."
            exit 1
        fi
    else
        echo "Using defined SECUDIR $secudirScript from $serviceSymlinkFile."
    fi
else
    echo "$serviceSymlinkFile is not set found or readable."
    exit 1
fi

if [ ! -x "sapgenpse" ]; then
    echo "sapgenpse could not be found or executed in this folder."
    exit 1
fi

generalName="scc"
pseName="${generalName}.pse"
exportCertName="${generalName}.crt"
if [ -e "${secudirScript}/${pseName}" ]; then
    echo "${secudirScript}/${pseName} already exists, cancel now."
    exit 1
fi

# find user of SCC process
sccUserName=`ps -ef | grep scc/daemon.sh | grep -v grep | cut -d' ' -f1 | head -n 1`
if [ -z "$sccUserName" ]; then
    echo "Can't identify User Name of Cloud Connector process, please make sure Cloud Connector service is running properly."
    exit 1
fi
echo "Cloud Connector is running with user $sccUserName"

csrName="sccCertificateRequest.p10"

read -p "Specify the own certificate name in the format as CN=host,OU=org,O=comp,C=lang: " ownCert
if [ -z "$ownCert" ]; then
    echo "Own certificate name not specified."
    exit 1
fi

read -p "Specify the PSE password: " psePW
if [ -z "$psePW" ]; then
    echo "No password specified."
    exit 1
fi

read -p "Specify the import certificate file of the partner contained in $secudirScript: " importCertName
if [ -z "$importCertName" ] || [ ! -r "$secudirScript/$importCertName" ]; then
    echo "$secudirScript/$importCertName could not be found or read."
    exit 1
fi

echo "Creating PSE now..."
echo 
./sapgenpse get_pse -v -p "$pseName" -x "$psePW" -r "$secudirScript/$csrName" "$ownCert"
if [ $? -ne 0 ]; then
    echo "Creation failed with error code $?."
    exit 1
fi

echo "PSE creation finished."

read -p "Do you want to import a CA response now? [y/n] " import_ca_bool

if [ "$import_ca_bool" == "y" ] || [ "$import_ca_bool" == "Y" ]; then
    read -p "Specify the CA response file contained in $secudirScript: " csrResponse
    if [ -z "$csrResponse" ] || [ ! -r "$secudirScript/$csrResponse" ]; then
        echo "$secudirScript/$csrResponse could not be found or read, skip import."
        read -p "Press any key to continue..."
    else
        read -p "Specify further Root CAs (PEM, Base64 or DER binary) in $secudirScript needed to complete the chain (separated by blanks), otherwise press enter: " rootCAs
        rootCAsList=
        if [ -n "$rootCAs" ]; then
            for rootCA in $rootCAs
            do
                rootCAsList="$rootCAsList -r $secudirScript/$rootCA"
            done
        fi

        echo "Importing CA response now..."
        echo 
        sh -c "./sapgenpse import_own_cert -v -p $pseName -x $psePW -c $secudirScript/$csrResponse $rootCAsList"
        if [ $? -ne 0 ]; then
            echo "Importing failed with error code $?."
            read -p "Press any key to continue..."
        fi
    fi
elif [ "$import_ca_bool" != "n" ] && [ "$import_ca_bool" != "N" ]; then
    echo "Unknown input $import_ca_bool, assuming no."
    read -p "Press any key to continue..."
fi

chmod 644 "$secudirScript/$pseName"

echo "Create SSO server credentials..."
echo 
./sapgenpse seclogin -v -p "$pseName" -x "$psePW" -O "$sccUserName"
if [ $? -ne 0 ]; then
    echo "Creation failed with error code $?."
    exit 1
fi

chmod 644 "$secudirScript/cred_v2"

echo "Creation finished."
echo "Export own certificate..."
echo 
./sapgenpse export_own_cert -v -o "$secudirScript/$exportCertName" -p "$pseName" -x "$psePW"
if [ $? -ne 0 ]; then
    echo "Export failed with error code $?."
    exit 1
fi

echo "Export finished."
echo "Import partner certificate into PSE file..."
echo 
./sapgenpse maintain_pk -v -a "$secudirScript/$importCertName" -p "$pseName" -x "$psePW"
if [ $? -ne 0 ]; then
    echo "Import failed with error code $?."
    exit 1
fi

echo "Completed."
exit 0