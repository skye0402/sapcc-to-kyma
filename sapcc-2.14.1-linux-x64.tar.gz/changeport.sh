#!/bin/bash

path=$(dirname $0)
[[ $path == "" ]] && path="."

javaCommand="java" # name of the Java launcher without the path
if [ ! -z "$JAVA_HOME" ]; then # $JAVA_HOME is not null
	javaExe="$JAVA_HOME/bin/$javaCommand" 
elif [ ! -z $(which java) ]; then # $JAVA_HOME is null (zero string)
	javaExe=$(which java) # file name of the Java application launcher executable
fi
if [ -z "$JAVA_HOME" ] | [ -z "$javaExe" ]; then echo "Could not find Java executable"; exit 5; fi

#check java version (grep is necessary in case JAVA_TOOL_OPTIONS is set as this changes the output of the command)
JAVA_VERSION=`$javaExe -version 2>&1 | grep version | awk 'NR==1{ gsub(/"/,""); gsub(/_[0-9]*/, ""); print $3 }'`
if [[ ! "$JAVA_VERSION" =~ 1\.[8]\. && ! "$JAVA_VERSION" =~ 11\. ]]
then
	echo "JAVA version is not correct. The supported versions are 1.8 and 11. Current java is $JAVA_VERSION"; 
	exit 5;
fi

if [ "$1" -le "1024" ]; then
    echo ""
    echo "WARNING"
    echo "Usage of privileged ports (below 1024) is restricted to root processes. Use port redirection if bind to $1 fails"
    echo ""
fi

${javaExe}  -Dusage="changeport.sh <port>" -jar $path/configurator.jar -dir $path -port $1

if [ $? -eq 0 ]; then
    echo Cloud Connector UI can now be reached via port $1
elif [ $? -eq 2 ]; then
  echo Failed to adjust the configuration to use port $1 for Cloud Connector UI using JVM ${javaExe}
fi

#in case it's a productive installation ensure that config files have the correct user and group after change
if [ `uname` != "Darwin" ]; then
   if [ `stat -c"%U" $path/conf` = "sccadmin" ]; then
     chown -R sccadmin:sccgroup $path/conf
   fi
fi


