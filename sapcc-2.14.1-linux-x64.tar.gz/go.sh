#!/bin/bash
###################### copied from catalina.sh
# compute default CATALINA_HOME and CATALINA_BASE
PRG="$0"

while [ -h "$PRG" ]; do
  ls=`ls -ld "$PRG"`
  link=`expr "$ls" : '.*-> \(.*\)$'`
  if expr "$link" : '/.*' > /dev/null; then
    PRG="$link"
  else
    PRG=`dirname "$PRG"`/"$link"
  fi
done

# Get standard environment variables
PRGDIR=`dirname "$PRG"`

# Only set CATALINA_HOME if not already set
[ -z "$CATALINA_HOME" ] && CATALINA_HOME=`pwd`

# Copy CATALINA_BASE from CATALINA_HOME if not already set
[ -z "$CATALINA_BASE" ] && CATALINA_BASE="$CATALINA_HOME"

# Ensure that neither CATALINA_HOME nor CATALINA_BASE contains a colon
# as this is used as the separator in the classpath and Java provides no
# mechanism for escaping if the same character appears in the path.
case $CATALINA_HOME in
  *:*) echo "Using CATALINA_HOME:   $CATALINA_HOME";
       echo "Unable to start as CATALINA_HOME contains a colon (:) character";
       exit 1;
esac
case $CATALINA_BASE in
  *:*) echo "Using CATALINA_BASE:   $CATALINA_BASE";
       echo "Unable to start as CATALINA_BASE contains a colon (:) character";
       exit 1;
esac

############ 


if [ ! -z "$JAVA_HOME" ]; then # $JAVA_HOME is not null
	javaExe="$JAVA_HOME/bin/java"
	kt="$JAVA_HOME/bin/keytool"
elif [ ! -z $(which java) ]; then # $JAVA_HOME is null (zero string)
	javaExe=$(which java) # file name of the Java application launcher executable
	if [ ! -z $(which keytool) ]; then
	   kt=$(which keytool)
	fi
fi
if [ -z "$JAVA_HOME" ] | [ -z "$javaExe" ]; then echo "Could not find Java executable"; exit 5; fi

#check java version (grep is necessary in case JAVA_TOOL_OPTIONS is set as this changes the output of the command)
JAVA_VERSION=`$javaExe -version 2>&1 | grep version | awk 'NR==1{ gsub(/"/,""); gsub(/_[0-9]*/, ""); print $3 }'`
if [[ ! "$JAVA_VERSION" =~ 1\.[8]\. && ! "$JAVA_VERSION" =~ 11\. ]]
then
	echo "JAVA version is not correct. The supported versions are 1.8 and 11. Current java is $JAVA_VERSION"; 
	exit 5;
fi

if [ ! -f "$CATALINA_BASE/config/ks.p12" ]; then
  echo "Generating initial key store for Administration UI"
  password=`$javaExe -cp $CATALINA_HOME/lib/com.sap.scc.t8util.jar:$CATALINA_HOME/bin/logback-classic.jar:$CATALINA_HOME/bin/logback-core.jar:$CATALINA_HOME/bin/slf4j-api.jar com.sap.scc.jni.SecStoreAccess -path . -po`
  $kt -genkey -v -keyalg RSA -keysize 2048 -sigalg SHA256withRSA -alias tomcat -validity 842 -storetype PKCS12 -storepass "$password" -keystore $CATALINA_BASE/config/ks.p12 -dname "CN=SCC, OU=Connectivity, O=SAP SE, C=DE" 2>/dev/null
  if [ $? -ne 0  ]; then
    echo "Was not able to create the keystore properly"
    rm -rf $SCCDIR/config/ks.p12
    exit 1
  else
    $kt -export -alias tomcat -keystore $CATALINA_BASE/config/ks.p12 -storepass "$password" -storetype PKCS12 -file  $CATALINA_BASE/config/tmp.cert 2>/dev/null
    if [ $? -ne 0  ]; then
      echo "Was not able to prepare certificate for trust store"
      rm -rf $SCCDIR/config/ks.p12
      exit 2
    else
      $kt -import -alias tomcattrust -file  $CATALINA_BASE/config/tmp.cert -keystore  $CATALINA_BASE/config/ks.p12 -storepass "$password" -storetype PKCS12 -noprompt  2>/dev/null
      if [ $? -ne 0  ]; then
        echo "Was not able to import certificate to trust store"
        rm -rf $CATALINA_BASE/config/ks.p12
        exit 3
      else
        rm -rf $CATALINA_BASE/config/tmp.cert
      fi
    fi
  fi
fi

echo 'Note: Closing this window will stop the cloud connector'
echo 'Art Text Start'
echo '   '
echo '   '
echo '   '
echo '         __  ___  ___      __        __   __          __                   '
echo '   |\ | /  \  |  |__  .   /  ` |    /  \ /__` | |\ | / _`                  '
echo '   | \| \__/  |  |___ .   \__, |___ \__/ .__/ | | \| \__>                  '
echo '                                                                           '
echo '   ___         __                  __   __                                 '
echo '    |  |__| | /__`    |  | | |\ | |  \ /  \ |  |    |  | | |    |          '
echo '    |  |  | | .__/    |/\| | | \| |__/ \__/ |/\|    |/\| | |___ |___       '
echo '                                                                           '
echo '             __  ___  __   __     ___       ___                            '
echo '            /__`  |  /  \ |__)     |  |__| |__                             '
echo '            .__/  |  \__/ |        |  |  | |___                            '
echo '                                                                           '
echo '    __        __        __      __   __             ___  __  ___  __   __  '
echo '   /  ` |    /  \ |  | |  \    /  ` /  \ |\ | |\ | |__  /  `  |  /  \ |__) '
echo '   \__, |___ \__/ \__/ |__/    \__, \__/ | \| | \| |___ \__,  |  \__/ |  \ '
echo '   '
echo '   '
echo '   '
echo 'Art Text End'


if [ -e $CATALINA_HOME/bin/catalina.sh ]
then

  if [ -z "$DEBUG" ]; then
	    DEBUG="0"
  fi
  if [	"$DEBUG" -eq "1" ]; then
	  if [ -z "$DEBUG_PORT" ]; then
	    DEBUG_PORT="localhost:8000"
	  fi
	  if [ -z "$DEBUG_SUSPEND" ]; then
	    DEBUG_SUSPEND="n"
	  fi
	  if [ -z "$JPDA_OPTS" ]; then
	    JPDA_OPTS="-agentlib:jdwp=transport=dt_socket,address=$DEBUG_PORT,server=y,suspend=$DEBUG_SUSPEND"
	  fi
	  CATALINA_OPTS="$JPDA_OPTS $CATALINA_OPTS"
	  export CATALINA_OPTS
  fi

  if "$javaExe" -version 2>&1| grep -q "SAP "; then
      XLOG_OPTS="-XtraceFile=log/vm_@PID_trace.log -XX:+GCHistory -XX:GCHistoryFilename=log/vm_@PID_gc.prf"
	  CATALINA_OPTS="$XLOG_OPTS $CATALINA_OPTS"
      echo "Use JVM log with configuration "$XLOG_OPTS
	  export CATALINA_OPTS
  elif [[ "$JAVA_VERSION" =~ 11\. ]]; then
      XLOG_OPTS="-Xlog:gc=info,all=warning:file=log/vm_%p_xlog.log:uptime,time,pid,tid:filecount=3,filesize=25M"
      mkdir -p $CATALINA_BASE/log
	  CATALINA_OPTS="$XLOG_OPTS $CATALINA_OPTS"
      echo "Use JVM log with configuration "$XLOG_OPTS
	  export CATALINA_OPTS
  fi

  rc=42
  while [ $rc -eq 42 ]
  do
    $CATALINA_HOME/bin/catalina.sh run;
    rc=$?
  done
else
 echo "catalina.sh script is not available"
 exit 1
fi

exit 0
